
export default function NovaStudioLanding() {
  return (
    <div className="min-h-screen bg-white text-gray-800 font-sans">
      <header className="bg-gray-900 text-white py-12 px-6 text-center">
        <h1 className="text-4xl font-bold mb-4">Your Website, Done Right. In 3 Days.</h1>
        <p className="text-lg">Professional websites for businesses, e-commerce stores, and personal brands — delivered fast, beautifully, and built to convert.</p>
        <button className="mt-6 px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md text-white font-semibold">
          Get Started Now
        </button>
      </header>

      <section className="py-16 px-6 text-center">
        <h2 className="text-3xl font-semibold mb-6">What I Offer</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-2">Business Sites</h3>
            <p>Position your business with clarity and confidence.</p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-2">eCommerce Stores</h3>
            <p>Sell with style through sleek product pages and smooth checkout flows.</p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-2">Personal Brand Sites</h3>
            <p>For coaches, creators, and consultants who want to stand out.</p>
          </div>
        </div>
      </section>

      <section className="bg-gray-100 py-16 px-6 text-center">
        <h2 className="text-3xl font-semibold mb-6">How It Works</h2>
        <ol className="space-y-4 max-w-2xl mx-auto text-left">
          <li><strong>1. Discovery –</strong> Fill out a quick form about your business and what you want.</li>
          <li><strong>2. Design & Build –</strong> I create a complete, customized website tailored to your needs.</li>
          <li><strong>3. Review & Launch –</strong> You review. I refine. We go live. Most sites are ready within 72 hours.</li>
        </ol>
      </section>

      <section className="py-16 px-6 text-center">
        <h2 className="text-3xl font-semibold mb-6">Flat Rate Pricing</h2>
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <div className="border p-6 rounded-2xl shadow">
            <h3 className="text-xl font-bold mb-2">Standard Package – $250</h3>
            <ul className="text-left list-disc list-inside">
              <li>Up to 5 fully designed pages</li>
              <li>Mobile-optimized layout</li>
              <li>Contact form</li>
              <li>7-day post-launch support</li>
            </ul>
          </div>
          <div className="border p-6 rounded-2xl shadow">
            <h3 className="text-xl font-bold mb-2">SEO Boost Package – $450</h3>
            <ul className="text-left list-disc list-inside">
              <li>Everything in Standard</li>
              <li>On-page SEO setup</li>
              <li>Keyword research</li>
              <li>Optimized content structure</li>
              <li>Google indexing setup</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="bg-gray-100 py-16 px-6 text-center">
        <h2 className="text-3xl font-semibold mb-6">Portfolio Preview</h2>
        <p className="mb-4">Want to see what I can do?</p>
        <p className="text-gray-600">Example site styles: Modern Consultant, Elegant Fashion Brand, Clean E-commerce Store</p>
      </section>

      <section className="py-16 px-6 text-center">
        <h2 className="text-3xl font-semibold mb-6">Contact Me</h2>
        <p className="mb-4">Ready to get started? Fill out the form below and I’ll reply within 24 hours.</p>
        <form action="mailto:novastudio@gmail.com" method="POST" className="max-w-xl mx-auto space-y-4">
          <input type="text" name="name" placeholder="Name" required className="w-full p-3 border rounded-xl" />
          <input type="email" name="email" placeholder="Email" required className="w-full p-3 border rounded-xl" />
          <input type="text" name="business" placeholder="Business Type" className="w-full p-3 border rounded-xl" />
          <textarea name="message" placeholder="Message" rows="4" className="w-full p-3 border rounded-xl"></textarea>
          <button type="submit" className="px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-xl text-white font-semibold">Send Message</button>
        </form>
      </section>

      <footer className="bg-gray-900 text-white py-6 text-center text-sm">
        &copy; {new Date().getFullYear()} NovaStudio. All rights reserved.
      </footer>
    </div>
  );
}
